package fr.votrerdvsante.beans;

public class MotifConsultation {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private String _identifiant;
	private Praticien _praticien;
	private Specialite _specialite;
	private DureeConsultation _dureeConsultation;
	private DureeTampon _dureeTampon;
	private String _libelle;
	private double _tarif;
	private boolean _tarifOk;
	
	
	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// ------------------

	private void Initialiser(){
		this._identifiant = null;
		this._praticien = null;
		this._specialite = null;
		this._dureeConsultation = null;
		this._dureeTampon = null;
		this._libelle = null;
		this._tarifOk = false;
	}

	public MotifConsultation(){
		this.Initialiser();
	}

	public MotifConsultation(
			final String identifiant,
			final Praticien praticien,
			final Specialite specialite,
			final DureeConsultation dureeConsultation,
			final DureeTampon dureeTampon,
			final String libelle,
			final double tarif){
		this.Initialiser();
		this.setIdentifiant(identifiant);
		this.setPraticien(praticien);
		this.setSpecialite(specialite);
		this.setDureeConsultation(dureeConsultation);
		this.setDureeTampon(dureeTampon);
		this.setLibelle(libelle);
		this.setTarif(tarif);
	}

	// Les accesseurs
	// ---------------

	public void setIdentifiant(final String s){
		this._identifiant = s;
	}

	public String getIdentifiant(){
		return (this._identifiant);
	}

	public void setPraticien(final Praticien praticien){
		this._praticien = praticien;
	}

	public Praticien getPraticien(){
		return (this._praticien);
	}

	public void setSpecialite(final Specialite specialite){
		this._specialite = specialite;
	}

	public Specialite getSpecialite(){
		return (this._specialite);
	}

	public void setDureeConsultation(final DureeConsultation dureeConsultation){
		this._dureeConsultation = dureeConsultation;
	}

	public DureeConsultation getDureeConsultation(){
		return (this._dureeConsultation);
	}

	public void setDureeTampon(final DureeTampon s){
		this._dureeTampon = s;
	}

	public DureeTampon getDureeTampon(){
		return (this._dureeTampon);
	}

	public void setLibelle(final String dureeTampon){
		this._libelle = dureeTampon;
	}

	public String getLibelle(){
		return (this._libelle);
	}

	public void setTarif(final double v){
		this._tarif = v;
		this._tarifOk = true;
	}

	public void setTarif(final String s){
		double a;
		boolean ok;

		ok = true;
		a = 0;
		try {
			a = Double.parseDouble(s);
		} catch (NumberFormatException e) {
			ok = false;
		}

		if (ok == true)
			this.setTarif(a);		
	}

	// retourne false si age n'est pas défini
	// sinon retourne true (la valeur est contenue
	// dans le paramètre de sortie)
	public boolean getTarif(double[] v){
		boolean d;

		d = this._tarifOk;
		if (d == true)
			v[0] = this._tarif;
		return (d);
	}

	// retourne la valeur de l'age sous forme
	// d'une chaine de caractères
	// retourne null si l'age n'est pas défini

	public String getTarif(){
		double[] a = new double[1];
		String s;

		if (this.getTarif(a)== true)
			s = String.format("%04d",a[0]);
		else
			s = null;
		return (s);		
	}

}
