package fr.votrerdvsante.beans;

public class DocumentPraticienPartage {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private DocumentPraticien _docPraticien;
	private DossierPatient _dossPatient;
	
	
	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// ------------------

	private void Initialiser(){		
		this._docPraticien = null;
		this._dossPatient = null;
	}

	public DocumentPraticienPartage(){
		this.Initialiser();
	}

	public DocumentPraticienPartage(
			final DocumentPraticien docPraticien,
			final DossierPatient dossPatient){
		this.Initialiser();
		this.setDocPraticien(docPraticien);
		this.setDossierPatient(dossPatient);
	}

	// Les accesseurs
	// ---------------

	public void setDocPraticien(final DocumentPraticien docPraticien){
		this._docPraticien = docPraticien;
	}

	public DocumentPraticien getDocPraticien(){
		return (this._docPraticien);
	}

	public void setDossierPatient(final DossierPatient dossPatient){
		this._dossPatient = dossPatient;
	}

	public DossierPatient getDossierPatient(){
		return (this._dossPatient);
	}

}
