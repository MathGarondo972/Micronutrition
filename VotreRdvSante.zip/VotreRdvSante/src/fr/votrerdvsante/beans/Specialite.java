package fr.votrerdvsante.beans;

public class Specialite {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private String _identifiant;
	private String _libelle;
	
	
	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// ------------------

	private void Initialiser(){
		this._identifiant = null;
		this._libelle = null;
	}

	public Specialite(){
		this.Initialiser();
	}

	public Specialite(
			final String identifiant,
			final String libelle){
		this.Initialiser();
		this.setIdentifiant(identifiant);
		this.setLibelle(libelle);
	}

	// Les accesseurs
	// ---------------

	public void setIdentifiant(final String s){
		this._identifiant = s;
	}

	public String getIdentifiant(){
		return (this._identifiant);
	}

	public void setLibelle(final String s){
		this._libelle = s;
	}

	public String getLibelle(){
		return (this._libelle);
	}

}
