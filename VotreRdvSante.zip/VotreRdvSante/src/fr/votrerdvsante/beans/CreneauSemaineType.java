package fr.votrerdvsante.beans;

public class CreneauSemaineType extends Creneau {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private Praticien _praticien;
	private Jour _jour;

	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// -----------------

	private void Initialiser(){
		this._praticien = null;
		this._jour = null;
	}

	public CreneauSemaineType(){
		super();
		this.Initialiser();
	}

	// surcharges du constructeur

	public CreneauSemaineType(
			final Praticien praticien,
			final Jour jour){
		super();
		this.Initialiser();
		this.setPraticien(praticien);
		this.setJour(jour);
	}

	// Les accesseurs
	// ---------------

	public void setPraticien(final Praticien praticien){
		this._praticien = praticien;
	}

	public Praticien getPraticien(){
		return (this._praticien);
	}

	public void setJour(final Jour jour){
		this._jour = jour;
	}

	public Jour getJour(){
		return (this._jour);
	}

}
