package fr.votrerdvsante.beans;

public class MessagePraticien extends Message {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private Praticien _praticien;
	private DossierPatient _dossPatient;

	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// -----------------

	private void Initialiser(){
		this._praticien = null;
		this._dossPatient = null;
	}

	public MessagePraticien(){
		super();
		this.Initialiser();
	}

	// surcharges du constructeur

	public MessagePraticien(
			final Praticien praticien,
			final DossierPatient dossPatient,
			final String body){
		super();
		this.Initialiser();
		this.setPraticien(praticien);
		this.setDossierPatient(dossPatient);
		this.setBody(body);
	}

	// Les accesseurs
	// ---------------

	public void setPraticien(final Praticien praticien){
		this._praticien = praticien;
	}

	public Praticien getPraticien(){
		return (this._praticien);
	}

	public void setDossierPatient(final DossierPatient dossPatient){
		this._dossPatient = dossPatient;
	}

	public DossierPatient getDossierPatient(){
		return (this._dossPatient);
	}

}
