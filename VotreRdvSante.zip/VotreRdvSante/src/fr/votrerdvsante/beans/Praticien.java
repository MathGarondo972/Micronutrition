package fr.votrerdvsante.beans;

public class Praticien extends Personne {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	//private String _;
	private boolean _flagReservable;

	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// -----------------

	private void Initialiser(){
		this._flagReservable = false;
		//this._ = null;
	}

	public Praticien(){
		super();
		this.Initialiser();
	}

	// surcharges du constructeur

	public Praticien(
			final String nom){
		super();
		this.Initialiser();
		this.setNom(nom);
	}
	
}
