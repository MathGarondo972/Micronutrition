package fr.votrerdvsante.beans;

public class DureeTampon extends Duree {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	//private String _;

	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// -----------------

	private void Initialiser(){
		//this._ = null;
	}

	public DureeTampon(){
		super();
		this.Initialiser();
	}

	// surcharges du constructeur

	public DureeTampon(
			final int nbrMinutes){
		super();
		this.Initialiser();
		this.setNbrMinutes(nbrMinutes);
	}

}
