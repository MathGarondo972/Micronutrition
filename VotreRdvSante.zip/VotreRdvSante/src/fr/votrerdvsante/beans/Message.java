package fr.votrerdvsante.beans;

public abstract class Message {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private String _identifiant;
	//private String _date;
	private String _body;
	private boolean _flagLu;
	private boolean _flagVisiblePraticien;
	private boolean _flagVisiblePatient;
	
	
	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// ------------------

	private void Initialiser(){
		this._identifiant = null;
		this._body = null;
		this._flagLu = false;
		this._flagVisiblePraticien = true;
		this._flagVisiblePatient = true;
	}

	public Message(){
		this.Initialiser();
	}

	public Message(
			final String identifiant,
			final String body){
		this.Initialiser();
		this.setIdentifiant(identifiant);
		this.setBody(body);
	}

	// Les accesseurs
	// ---------------

	public void setIdentifiant(final String s){
		this._identifiant = s;
	}

	public String getIdentifiant(){
		return (this._identifiant);
	}

	public void setBody(final String s){
		this._body = s;
	}

	public String getBody(){
		return (this._body);
	}

}
