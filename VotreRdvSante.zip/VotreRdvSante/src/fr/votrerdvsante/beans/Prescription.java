package fr.votrerdvsante.beans;

public class Prescription {

}
