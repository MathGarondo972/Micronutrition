package fr.votrerdvsante.beans;

public class Laboratoire {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private String _identifiant;
	private Praticien _praticien;
	private String _libelle;

	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// -----------------

	private void Initialiser(){
		this._identifiant = null;
		this._praticien = null;
		this._libelle = null;
	}

	public Laboratoire(){
		this.Initialiser();
	}

	// surcharges du constructeur

	public Laboratoire(
			final String identifiant,
			final Praticien praticien,
			final String libelle){
		this.Initialiser();
		this.setIdentifiant(identifiant);
		this.setPraticien(praticien);
		this.setLibelle(libelle);
	}

	// Les accesseurs
	// ---------------

	public void setIdentifiant(final String s){
		this._identifiant = s;
	}

	public String getIdentifiant(){
		return (this._identifiant);
	}

	public void setPraticien(final Praticien praticien){
		this._praticien = praticien;
	}

	public Praticien getPraticien(){
		return (this._praticien);
	}

	public void setLibelle(final String s){
		this._libelle = s;
	}

	public String getLibelle(){
		return (this._libelle);
	}

}
