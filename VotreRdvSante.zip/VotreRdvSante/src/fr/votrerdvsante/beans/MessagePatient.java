package fr.votrerdvsante.beans;

public class MessagePatient extends Message {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private Patient _patient;
	private DossierPatient _dossPatient;

	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// -----------------

	private void Initialiser(){
		this._patient = null;
		this._dossPatient = null;
	}

	public MessagePatient(){
		super();
		this.Initialiser();
	}

	// surcharges du constructeur

	public MessagePatient(
			final Patient patient,
			final DossierPatient dossPatient,
			final String body){
		super();
		this.Initialiser();
		this.setPatient(patient);
		this.setDossierPatient(dossPatient);
		this.setBody(body);
	}

	// Les accesseurs
	// ---------------

	public void setPatient(final Patient patient){
		this._patient = patient;
	}

	public Patient getPatient(){
		return (this._patient);
	}

	public void setDossierPatient(final DossierPatient dossPatient){
		this._dossPatient = dossPatient;
	}

	public DossierPatient getDossierPatient(){
		return (this._dossPatient);
	}

}
