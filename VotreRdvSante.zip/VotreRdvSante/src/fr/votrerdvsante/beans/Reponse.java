package fr.votrerdvsante.beans;

public class Reponse {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private String _identifiant;
	private CreneauRdv _crenauRdv;
	private Question _question;
	private int _ordre;
	private boolean _ordreOk;
	private String _libelle;
	
	
	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// ------------------

	private void Initialiser(){
		this._identifiant = null;
		this._crenauRdv = null;
		this._question = null;
		this._ordreOk = false;
		this._libelle = null;
	}

	public Reponse(){
		this.Initialiser();
	}

	public Reponse(
			final String identifiant,
			final CreneauRdv crenauRdv,
			final Question question,
			final int ordre,
			final String libelle){
		this.Initialiser();
		this.setIdentifiant(identifiant);
		this.setLibelle(libelle);
	}

	// Les accesseurs
	// ---------------

	public void setIdentifiant(final String s){
		this._identifiant = s;
	}

	public String getIdentifiant(){
		return (this._identifiant);
	}

	public void setCreneauRdv(final CreneauRdv crenauRdv){
		this._crenauRdv = crenauRdv;
	}

	public CreneauRdv getCreneauRdv(){
		return (this._crenauRdv);
	}

	public void setQuestion(final Question question){
		this._question = question;
	}

	public Question getQuestion(){
		return (this._question);
	}

	public void setOrdre(final int v){
		this._ordre = v;
		this._ordreOk = true;
	}

	public void setOrdre(final String s){
		int a;
		boolean ok;

		ok = true;
		a = 0;
		try {
			a = Integer.parseInt(s);
		} catch (NumberFormatException e) {
			ok = false;
		}

		if (ok == true)
			this.setOrdre(a);		
	}

	// retourne false si age n'est pas défini
	// sinon retourne true (la valeur est contenue
	// dans le paramètre de sortie)
	public boolean getOrdre(int[] v){
		boolean d;

		d = this._ordreOk;
		if (d == true)
			v[0] = this._ordre;
		return (d);
	}

	// retourne la valeur de l'age sous forme
	// d'une chaine de caractères
	// retourne null si l'age n'est pas défini

	public String getOrdre(){
		int[] a = new int[1];
		String s;

		if (this.getOrdre(a)== true)
			s = String.format("%04d",a[0]);
		else
			s = null;
		return (s);		
	}

	public void setLibelle(final String s){
		this._libelle = s;
	}

	public String getLibelle(){
		return (this._libelle);
	}

}
