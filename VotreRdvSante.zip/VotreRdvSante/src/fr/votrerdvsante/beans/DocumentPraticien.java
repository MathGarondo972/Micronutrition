package fr.votrerdvsante.beans;

public class DocumentPraticien extends Document {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private Praticien _praticien;

	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// -----------------

	private void Initialiser(){
		this._praticien = null;
	}

	public DocumentPraticien(){
		super();
		this.Initialiser();
	}

	// surcharges du constructeur

	public DocumentPraticien(
			final Praticien praticien){
		super();
		this.Initialiser();
		this.setPraticien(praticien);
	}

	// Les accesseurs
	// ---------------

	public void setPraticien(final Praticien praticien){
		this._praticien = praticien;
	}

	public Praticien getPraticien(){
		return (this._praticien);
	}

}
