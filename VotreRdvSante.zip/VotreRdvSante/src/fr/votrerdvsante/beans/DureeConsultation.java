package fr.votrerdvsante.beans;

public class DureeConsultation extends Duree {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	//private String _;

	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// -----------------

	private void Initialiser(){
		//this._ = null;
	}

	public DureeConsultation(){
		super();
		this.Initialiser();
	}

	// surcharges du constructeur

	public DureeConsultation(
			final int nbrMinutes){
		super();
		this.Initialiser();
		this.setNbrMinutes(nbrMinutes);
	}

}
