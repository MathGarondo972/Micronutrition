package fr.votrerdvsante.beans;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.naming.spi.DirStateFactory.Result;

public class ConnexionMySQL {
	public static void main(String [] args) {	
		
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/votrerdvsante?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", "root", "");
			System.out.println("Succes Connexion");
		} catch (Exception e) {
			System.err.println(e);
				}
	}
}
