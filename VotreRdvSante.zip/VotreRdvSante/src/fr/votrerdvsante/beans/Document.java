package fr.votrerdvsante.beans;

public abstract class Document {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private String _identifiant;
	//private Date _date;
	private String _libelle;
	private double _taille;
	private boolean _tailleOk;
	private boolean _flagVisible;
	
	
	
	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// ------------------

	private void Initialiser(){
		this._identifiant = null;
		this._libelle = null;
		this._tailleOk = false;
		this._flagVisible = true;
	}

	public Document(){
		this.Initialiser();
	}

	public Document(
			final String identifiant,
			final String libelle,
			final double taille){
		this.Initialiser();
		this.setIdentifiant(identifiant);
		this.setLibelle(libelle);
		this.setTaille(taille);
	}

	// Les accesseurs
	// ---------------

	public void setIdentifiant(final String s){
		this._identifiant = s;
	}

	public String getIdentifiant(){
		return (this._identifiant);
	}

	public void setLibelle(final String s){
		this._libelle = s;
	}

	public String getLibelle(){
		return (this._libelle);
	}

	public void setTaille(final double v){
		this._taille = v;
		this._tailleOk = true;
	}

	public void setTaille(final String s){
		double a;
		boolean ok;

		ok = true;
		a = 0;
		try {
			a = Double.parseDouble(s);
		} catch (NumberFormatException e) {
			ok = false;
		}

		if (ok == true)
			this.setTaille(a);		
	}

	// retourne false si age n'est pas défini
	// sinon retourne true (la valeur est contenue
	// dans le paramètre de sortie)
	public boolean getTaille(double[] v){
		boolean d;

		d = this._tailleOk;
		if (d == true)
			v[0] = this._taille;
		return (d);
	}

	// retourne la valeur de l'age sous forme
	// d'une chaine de caractères
	// retourne null si l'age n'est pas défini

	public String getTaille(){
		double[] a = new double[1];
		String s;

		if (this.getTaille(a)== true)
			s = String.format("%04d",a[0]);
		else
			s = null;
		return (s);		
	}

}
