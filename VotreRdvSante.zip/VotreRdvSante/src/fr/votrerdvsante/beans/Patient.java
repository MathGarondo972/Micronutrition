package fr.votrerdvsante.beans;

public class Patient extends Personne {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	//private String _;

	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// -----------------

	private void Initialiser(){
		//this._ = null;
	}

	public Patient(){
		super();
		this.Initialiser();
	}

	// surcharges du constructeur

	public Patient(
			final String nom){
		super();
		this.Initialiser();
		this.setNom(nom);
	}
	
}
