package fr.votrerdvsante.beans;

public abstract class Duree {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private String _identifiant;
	//private String _date;
	private int _nbrMinutes;
	private boolean _nbrMinutesOk;
	
	
	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// ------------------

	private void Initialiser(){
		this._identifiant = null;
		this._nbrMinutesOk = false;
	}

	public Duree(){
		this.Initialiser();
	}

	public Duree(
			final String identifiant,
			final int nbrMinutes){
		this.Initialiser();
		this.setIdentifiant(identifiant);
		this.setNbrMinutes(nbrMinutes);
	}

	// Les accesseurs
	// ---------------

	public void setIdentifiant(final String s){
		this._identifiant = s;
	}

	public String getIdentifiant(){
		return (this._identifiant);
	}

	public void setNbrMinutes(final int v){
		this._nbrMinutes = v;
		this._nbrMinutesOk = true;
	}

	public void setNbrMinutes(final String s){
		int a;
		boolean ok;

		ok = true;
		a = 0;
		try {
			a = Integer.parseInt(s);
		} catch (NumberFormatException e) {
			ok = false;
		}

		if (ok == true)
			this.setNbrMinutes(a);		
	}

	// retourne false si age n'est pas défini
	// sinon retourne true (la valeur est contenue
	// dans le paramètre de sortie)
	public boolean getNbrMinutes(int[] v){
		boolean d;

		d = this._nbrMinutesOk;
		if (d == true)
			v[0] = this._nbrMinutes;
		return (d);
	}

	// retourne la valeur de l'age sous forme
	// d'une chaine de caractères
	// retourne null si l'age n'est pas défini

	public String getNbrMinutes(){
		int[] a = new int[1];
		String s;

		if (this.getNbrMinutes(a)== true)
			s = String.format("%04d",a[0]);
		else
			s = null;
		return (s);		
	}

}
