package fr.votrerdvsante.beans;

public class Medicament {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private String _identifiant;
	private Laboratoire _laboratoire;
	private String _libelle;
	private String _posologieDefault;
	private boolean _flagVisible;
	
	
	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// ------------------

	private void Initialiser(){
		this._identifiant = null;
		this._laboratoire = null;
		this._libelle = null;
		this._posologieDefault = null;
		this._flagVisible = true;
	}

	public Medicament(){
		this.Initialiser();
	}

	public Medicament(
			final String identifiant,
			final Laboratoire laboratoire,
			final String libelle,
			final String posologieDefault){
		this.Initialiser();
		this.setIdentifiant(identifiant);
		this.setLaboratoire(laboratoire);
		this.setLibelle(libelle);
		this.setPosologieDefault(posologieDefault);
	}

	// Les accesseurs
	// ---------------

	public void setIdentifiant(final String s){
		this._identifiant = s;
	}

	public String getIdentifiant(){
		return (this._identifiant);
	}

	public void setLaboratoire(final Laboratoire laboratoire){
		this._laboratoire = laboratoire;
	}

	public Laboratoire getLaboratoire(){
		return (this._laboratoire);
	}

	public void setLibelle(final String s){
		this._libelle = s;
	}

	public String getLibelle(){
		return (this._libelle);
	}

	public void setPosologieDefault(final String s){
		this._posologieDefault = s;
	}

	public String getPosologieDefault(){
		return (this._posologieDefault);
	}

}
