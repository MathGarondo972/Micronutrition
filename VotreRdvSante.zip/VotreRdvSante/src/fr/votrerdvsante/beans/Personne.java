package fr.votrerdvsante.beans;

public abstract class Personne {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private String _identifiant;
	private String _email;
	private String _motPasse;
	//private Date dateInscription;
	private String _nom;
	private String _prenom;
	//private Date dateNaissance;
	private String _sexe;
	private String _adresse;
	private String _codePostal;
	private String _ville;
	private String _pays;
	private String _numeroTelephone;
	
	
	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// ------------------

	private void Initialiser(){
		this._identifiant = null;
		this._email = null;
		this._motPasse = null;
		this._nom = null;
		this._prenom = null;
		this._sexe = null;
		this._adresse = null;
		this._codePostal = null;
		this._ville = null;
		this._pays = null;
		this._numeroTelephone = null;
	}

	public Personne(){
		this.Initialiser();
	}

	public Personne(
			final String identifiant,
			final String email,
			final String motPasse,
			final String nom,
			final String prenom,
			final String sexe,
			final String adresse,
			final String codePostal,
			final String ville,
			final String pays,
			final String numeroTelephone){
		this.Initialiser();
		this.setIdentifiant(identifiant);
		this.setEmail(email);
		this.setMotPasse(motPasse);
		this.setNom(nom);
		this.setPrenom(prenom);
		this.setSexe(sexe);
		this.setAdresse(adresse);
		this.setCodePostal(codePostal);
		this.setVille(ville);
		this.setPays(pays);
		this.setNumeroTelephone(numeroTelephone);
	}

	// Les accesseurs
	// ---------------

	public void setIdentifiant(final String s){
		this._identifiant = s;
	}

	public String getIdentifiant(){
		return (this._identifiant);
	}

	public void setEmail(final String s){
		this._email = s;
	}

	public String getEmail(){
		return (this._email);
	}

	public void setMotPasse(final String s){
		this._motPasse = s;
	}

	public String getMotPasse(){
		return (this._motPasse);
	}

	public void setNom(final String s){
		this._nom = s;
	}

	public String getNom(){
		return (this._nom);
	}

	public void setPrenom(final String s){
		this._prenom = s;
	}

	public String getPrenom(){
		return (this._prenom);
	}

	public void setSexe(final String s){
		this._sexe = s;
	}

	public String getSexe(){
		return (this._sexe);
	}

	public void setAdresse(final String s){
		this._adresse = s;
	}

	public String getAdresse(){
		return (this._adresse);
	}

	public void setCodePostal(final String s){
		this._codePostal = s;
	}

	public String getCodePostal(){
		return (this._codePostal);
	}

	public void setVille(final String s){
		this._ville = s;
	}

	public String getVille(){
		return (this._ville);
	}

	public void setPays(final String s){
		this._pays = s;
	}

	public String getPays(){
		return (this._pays);
	}

	public void setNumeroTelephone(final String s){
		this._numeroTelephone = s;
	}

	public String getNumeroTelephone(){
		return (this._numeroTelephone);
	}

}
