package fr.votrerdvsante.beans;

public class DocumentPatient extends Document {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private Patient _patient;
	private DossierPatient _dossPatient;

	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// -----------------

	private void Initialiser(){
		this._patient = null;
		this._dossPatient = null;
	}

	public DocumentPatient(){
		super();
		this.Initialiser();
	}

	// surcharges du constructeur

	public DocumentPatient(
			final Patient patient,
			final DossierPatient dossPatient){
		super();
		this.Initialiser();
		this.setPatient(patient);
		this.setDossierPatient(dossPatient);
	}

	// Les accesseurs
	// ---------------

	public void setPatient(final Patient patient){
		this._patient = patient;
	}

	public Patient getPatient(){
		return (this._patient);
	}

	public void setDossierPatient(final DossierPatient dossPatient){
		this._dossPatient = dossPatient;
	}

	public DossierPatient getDossierPatient(){
		return (this._dossPatient);
	}

}
