package fr.votrerdvsante.beans;

public class CreneauSupplementaire extends Creneau {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private Praticien _praticien;
	private TypeCreneau _typeCreneau;

	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// -----------------

	private void Initialiser(){
		this._praticien = null;
	}

	public CreneauSupplementaire(){
		super();
		this.Initialiser();
	}

	// surcharges du constructeur

	public CreneauSupplementaire(
			final Praticien praticien,
			final TypeCreneau typeCreneau){
		super();
		this.Initialiser();
		this.setPraticien(praticien);
		this.setTypeCreneau(typeCreneau);
	}

	// Les accesseurs
	// ---------------

	public void setPraticien(final Praticien praticien){
		this._praticien = praticien;
	}

	public Praticien getPraticien(){
		return (this._praticien);
	}

	public void setTypeCreneau(final TypeCreneau typeCreneau){
		this._typeCreneau = typeCreneau;
	}

	public TypeCreneau getTypeCreneau(){
		return (this._typeCreneau);
	}

}
