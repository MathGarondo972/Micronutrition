package fr.votrerdvsante.beans;

public class DossierPatient {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private Patient _patient;
	private Praticien _praticien;
	
	
	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// ------------------

	private void Initialiser(){
		this._patient = null;
		this._praticien = null;
	}

	public DossierPatient(){
		this.Initialiser();
	}

	public DossierPatient(
			final Patient patient,
			final Praticien praticien){
		this.Initialiser();
		this.setPatient(patient);
		this.setPraticien(praticien);
	}

	// Les accesseurs
	// ---------------

	public void setPatient(final Patient patient){
		this._patient = patient;
	}

	public Patient getPatient(){
		return (this._patient);
	}

	private void setPraticien(final Praticien praticien){
		this._praticien = praticien;
	}

	public Praticien getPraticien(){
		return (this._praticien);
	}

}
