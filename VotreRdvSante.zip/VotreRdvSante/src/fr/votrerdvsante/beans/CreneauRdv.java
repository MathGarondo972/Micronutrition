package fr.votrerdvsante.beans;

public class CreneauRdv extends Creneau {

	// -------------------------
	// Les attributs d'instance
	// -------------------------

	private DossierPatient _dossPatient;
	private MotifConsultation _motifConsultation;
	private StatutRdv _statutRdv;
	//private TypePaiement _paiement;

	// -------------------------
	// Les méthodes d'instance
	// -------------------------

	// Les constructeurs
	// -----------------

	private void Initialiser(){
		this._dossPatient = null;
		this._motifConsultation = null;
		this._statutRdv = null;
	}

	public CreneauRdv(){
		super();
		this.Initialiser();
	}

	// surcharges du constructeur

	public CreneauRdv(
			final DossierPatient dossPatient,
			final MotifConsultation motifConsultation,
			final StatutRdv statutRdv){
		super();
		this.Initialiser();
		this.setDossierPatient(dossPatient);
		this.setMotifConsultation(motifConsultation);
		this.setStatutRdv(statutRdv);
	}

	// Les accesseurs
	// ---------------

	public void setDossierPatient(final DossierPatient dossPatient){
		this._dossPatient = dossPatient;
	}

	public DossierPatient getDossierPatient(){
		return (this._dossPatient);
	}

	public void setMotifConsultation(final MotifConsultation motifConsultation){
		this._motifConsultation = motifConsultation;
	}

	public MotifConsultation getMotifConsultation(){
		return (this._motifConsultation);
	}

	public void setStatutRdv(final StatutRdv statutRdv){
		this._statutRdv = statutRdv;
	}

	public StatutRdv getStatutRdv(){
		return (this._statutRdv);
	}
	
}
