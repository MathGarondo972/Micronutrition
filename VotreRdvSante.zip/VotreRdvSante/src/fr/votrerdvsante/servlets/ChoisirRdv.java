package fr.votrerdvsante.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ChoisirRdv extends HttpServlet {
	
	public static final String VUE = "/WEB-INF/template.jsp";
	public static final String CONTENU = "choisirRdv";
    public static final String ATT_NOMFICHIER = "nomFichier";
    public static final String CHAMP_SPECIALITE = "specialite";
    public static final String CHAMP_LIEU = "lieu";
    public static final String ATT_SPECIALITE = "specialite";
    public static final String ATT_LIEU = "lieu";
	
	public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
		request.setAttribute(ATT_NOMFICHIER,CONTENU);	
		this.getServletContext().getRequestDispatcher(VUE).forward( request, response );
		
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String specialite = request.getParameter(CHAMP_SPECIALITE);
		String lieu = request.getParameter(CHAMP_LIEU);

		request.setAttribute(ATT_NOMFICHIER,CONTENU);	
        request.setAttribute(ATT_SPECIALITE,specialite);
        request.setAttribute(ATT_LIEU,lieu);
        
        this.getServletContext().getRequestDispatcher(VUE).forward( request, response );     
	}

}
