package com.sdzee.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class InscriptionPraticien extends HttpServlet {
	public static final String VUE			 	= "/WEB-INF/inscritionPraticien.jsp";
	public static final String CHAMP_EMAIL	 	= "email";
	public static final String CHAMP_MOTPASS 	= "motdepasse";
	public static final String CHAMP_NOM	 	= "nom";
	public static final String CHAMP_PRENOM  	= "prenom";
	public static final String CHAMP_SPECIALITE = "specialite";
	public static final String CHAMP_VILLE   	= "ville";
	public static final String CHAMP_TEXTAREA	= "adress";
	
	public void doGet( HttpServletRequest request, HttpServletResponse response ) throws
ServletException, IOException{
		/* Affichage de la page d'inscription */
		this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	}
	
	public void doPost( HttpServletRequest request, HttpServletResponse response ) throws
ServletException, IOException{
		String resultat;
		Map<String, String> erreurs = new HashMap<String, String>();
		
		/* Récupération des champs du formulaire */
		String email = request.getParameter( CHAMP_EMAIL );
		String motdepasse = request.getParameter(CHAMP_MOTPASS);
		String nom = request.getParameter(CHAMP_NOM);
		String prenom = request.getParameter(CHAMP_PRENOM);
		String specialite = request.getParameter(CHAMP_SPECIALITE);
		String ville = request.getParameter(CHAMP_VILLE);
		String adress = request.getParameter(CHAMP_TEXTAREA);
		
		/* Validation du champ email */
		try {
			validationEmail( email );
		} catch ( Exception e ) {
			erreurs.put( CHAMP_EMAIL, e.getMessage() );
		}
		
		/* Validation du champs mot de passe */
		try {
			validationMotpass( motpass );
		} catch ( Exception e ) {
			erreurs.put( CHAMP_MOTPASS, e.getMessage() );
		}
		
		/* Validation du champs nom */
		try {
			validationNom( nom );
		} catch ( Exception e ) {
			erreurs.put( CHAMP_NOM, e.getMessage() );
		}
		
		/* Validation du champs prenom */
		try {
			validationPrenom( prenom );
		} catch ( Exception e ) {
			erreurs.put( CHAMP_PRENOM, e.getMessage() );
		}
		
		/* Validation du champs specialite */
		try {
			validationSpecialite( specialite );
		} catch ( Exception e ) {
			erreurs.put( CHAMP_SPECIALITE, e.getMessage() );
		}
		
		/* Validation du champs ville */
		try {
			validationVille( ville );
		} catch ( Exception e ) {
			erreurs.put( CHAMP_VILLE, e.getMessage() );
		}
		
		/* Validation du champs adresse */
		try {
			validationTextarea( adress );
		} catch ( Exception e ) {
			erreurs.put( CHAMP_TEXTAREA, e.getMessage() );
		}
		
		/* Initialisation du résultat global de la validation. */
        if ( erreurs.isEmpty() ) {
            resultat = "Succès de l'inscription.";
        } else {
            resultat = "Échec de l'inscription.";
        }
        
        /* Stockage du résultat et des messages d'erreur dans l'objet request */
        request.setAttribute( ATT_ERREURS, erreurs );
        request.setAttribute( ATT_RESULTAT, resultat );
        
	}
}
