package com.sdzee.forms;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.sdzee.beans.Personne;

public class InscriptionForm {
	private static final String CHAMP_EMAIL			= "email";
	private static final String CHAMP_MOTPASS		= "motpass";
	private static final String CHAMP_NOM			= "nom";
	private static final String CHAMP_PRENOM		= "prenom";
	private static final String CHAMP_VILLE			= "ville";
	private static final String CHAMP_SPECIALITE	= "specialite";
	private static final String CHAMP_TEXTAREA		= "adress";
	
	private String              resultat;
	private Map<String, String> erreurs      = new HashMap<String, String>();

	public String getResultat() {
	    return resultat;
	}

	public Map<String, String> getErreurs() {
	    return erreurs;
	}
	
	public Personne inscrirePersonne( HttpServletRequest request ) {
		String email = getValeurChamp( request, CHAMP_EMAIL );
		String motpass = getValeurChamp( request, CHAMP_MOTPASS );
		String nom = getValeurChamp( request, CHAMP_NOM );
		String prenom = getValeurChamp( request, CHAMP_PRENOM );
		String ville = getValeurChamp( request, CHAMP_VILLE );
		String adress = getValeurChamp( request, CHAMP_TEXTAREA);
		String specialite = getValeurChamp( request, CHAMP_SPECIALITE);
		
		Personne personne = new Personne();
		
		try {
			validationEmail( email );
		} catch ( Exception e ) {
			setErreur( CHAMP_EMAIL, e.getMessage() );
		}
		personne.setEmail( email );
		
		try {
			validationMotpass( motpass );
		} catch ( Exception e ) {
			setErreur( CHAMP_MOTPASS, e.getMessage() );
		}
		personne.setMotpass(motpass);
		
		try {
			validationNom( nom );
		} catch ( Exception e ) {
			setErreur( CHAMP_NOM, e.getMessage() );
		}
		personne.setNom(nom);
		
		try {
			validationPrenom( prenom );
		} catch ( Exception e ) {
			setErreur( CHAMP_PRENOM, e.getMessage() );
		}
		personne.setPrenom(prenom);
		
		try {
			validationVille( ville );
		} catch ( Exception e ) {
			setErreur( CHAMP_VILLE, e.getMessage() );
		}
		personne.setVille(ville);
		
		try {
			validationSpecialite( specialite );
		} catch ( Exception e ) {
			setErreur( CHAMP_SPECIALITE, e.getMessage() );
		}
		personne.setSpecialite(specialite);
		
		try {
			validationTextarea( adress );
		} catch (Exception e ) {
			setErreur( CHAMP_TEXTAREA, e.getMessage() );
		}
		personne.setTextarea(adress);
		
		if ( erreurs.isEmpty() ) {
	        resultat = "Succès de l'inscription.";
	    } else {
	        resultat = "Échec de l'inscription.";
	    }

	    return personne;
	    
	    private void validationEmail( String email ) throws Exception {
	    	if ( email != null ) {
	            if ( !email.matches( "([^.@]+)(\\.[^.@]+)*@([^.@]+\\.)+([^.@]+)" ) ) {
	                throw new Exception( "Merci de saisir une adresse mail valide." );
	            }
	        } else {
	            throw new Exception( "Merci de saisir une adresse mail." );
	        }
	    }
	    
	    private void validationMotpass( String motpass ) throws Exception {
	    	if ( motpass != null ) {
	        } else ( motpass.length() < 3 ) {
	                throw new Exception( "Les mots de passe doivent contenir au moins 3 caractères." );
	        }
	    }
	    
	    private void validationNom( String nom ) throws Exception {
	        if ( nom != null && nom.length() < 3 ) {
	            throw new Exception( "Le nom d'utilisateur doit contenir au moins 3 caractères." );
	        }
	    }
	    
	    private void validationPrenom( String prenom ) throws Exception {
	        if ( prenom != null && prenom.length() < 3 ) {
	            throw new Exception( "Le prenom d'utilisateur doit contenir au moins 3 caractères." );
	        }
	    }
	    
	    private void validationVille( String ville ) throws Exception {
	        if ( ville != null && ville.length() < 3 ) {
	            throw new Exception( "La ville d'utilisateur doit contenir au moins 3 caractères." );
	        }
	    }
	    
	    private void validationTextarea( String adress ) throws Exception {
	        if ( adress != null && adress.length() < 3 ) {
	            throw new Exception( "Le nom d'utilisateur doit contenir au moins 3 caractères." );
	        }
	    }
	    
	    /*
	     * Ajoute un message correspondant au champ spécifié à la map des erreurs.
	     */
	    private void setErreur( String champ, String message ) {
	        erreurs.put( champ, message );
	    }

	    /*
	     * Méthode utilitaire qui retourne null si un champ est vide, et son contenu
	     * sinon.
	     */
	    private static String getValeurChamp( HttpServletRequest request, String nomChamp ) {
	        String valeur = request.getParameter( nomChamp );
	        if ( valeur == null || valeur.trim().length() == 0 ) {
	            return null;
	        } else {
	            return valeur.trim();
	        }
	    }
	    
	    
	}
}
