package com.sdzee.forms;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.sdzee.beans.Personne;

public class ConnexionForm {
	private static final String CHAMP_EMAIL		= "email";
	private static final String CHAMP_MOTPASS	= "motpass";
	
	private String resultat;
	private Map<String, String> erreurs = new HashMap<String, String>();
	
	public String getResultat() {
		return resultat;
	}
	
	public Map<String, String> getErreurs() {
		return erreurs;
	}
	
	public Personne connecterPersonne( HttpServletRequest request ) {
		/* Récupération des champs du formulaire */
		String email = getValeurChamp( request, CHAMP_EMAIL );
		String motpass = getValeurChamp ( request, CHAMP_MOTPASS);
		
		Personne personne = new Personnne();
		
		/* Validation du champ email */
		try {
			validationEmail ( email );
		} catch ( Exception e) {
			setErreur ( CHAMP_EMAIL, e.getMessage() );
		}
		personne.setEmail( email );
		
		/* Validation du champ mot de passe */
		try {
			validationMotpass ( motpass );
		} catch( Exception e ) {
			setErreur ( CHAMP_MOTPASS, e.getMessage() );
		}
		personne.setMotpass(motpass);
		
		/* Initialisation du résultat global de la validation */
		if ( erreurs.isEmpty() ) {
			resultat = "Succès de la connexion";
		} else {
			resultat = "Échec de la connexion";
		}
		return resultat;
		
		/**
		 * Valide l'adresse email saisie
		 */
		private void validationEmail( String email ) throws Exception{
			if ( email != null && !email.matches( "([^.@]+)(\\.[^.@]+)*@([^.@]+\\.)+([^.@]+)" ) ) {
				throw new Exception( "Merci de saisir une adresse mail valide !");
			}
		}
		
		/**
		 * Valide le mot de passe saisie
		 */
		private void validationMotpass( String motpass ) throws Exception{
			if ( motpass != null ) {
	            if ( motpass.length() < 3 ) {
	                throw new Exception( "Le mot de passe doit contenir au moins 3 caractères." );
	            }
	        } else {
	            throw new Exception( "Merci de saisir votre mot de passe." );
	        }
		}
		
		/**
		 * Ajoute un message correspondant au champ spécifié à la map erreur 
		 */
		private void setErreur( String champs, String message) {
			erreurs.put( champs, message );
		}
		
		/*
		 * Méthode utilitaire qui retourne null si un champ est vide, et son contenu
		 * sinon.
		 */
		private static String getValeurChamp( HttpServletRequest request, String nomChamp ) {
	        String valeur = request.getParameter( nomChamp );
	        if ( valeur == null || valeur.trim().length() == 0 ) {
	            return null;
	        } else {
	            return valeur;
	        }
	}
}
