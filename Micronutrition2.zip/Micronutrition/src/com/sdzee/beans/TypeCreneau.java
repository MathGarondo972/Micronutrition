package com.sdzee.beans;

public class TypeCreneau {
	/* Propriété du bean */
	private String libelle;
	
	public void setLibelle ( String libelle) {
		this.libelle = libelle;
	}
	
	public String getLibelle () {
		return libelle;
	}

}
