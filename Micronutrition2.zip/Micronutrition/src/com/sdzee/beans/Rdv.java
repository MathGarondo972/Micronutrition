package com.sdzee.beans;

public class Rdv {
	/*Propriété du bean*/
	private String date;
	private String hashcode;
	private Double montant;
	/* private statutPaiement; */
	
	public void setDate ( String date ) {
		this.date = date;
	}
	
	public String getDate() {
		return date;
	}
	
	public void setHashcode ( String hashcode ) {
		this.hashcode = hashcode;
	}
	
	public String getHashcode () {
		return hashcode;
	}
	
	public void setMontant ( Double montant ) {
		this.montant = montant;
	}
	
	public Double getMontant () {
		return montant;
	}

}
