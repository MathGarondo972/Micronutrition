package com.sdzee.beans;

public class CreneauxSupp {
	/* Propriété du bean
	 * private Date dateDebut;
	 * private Date dateFin;
	 */
}
