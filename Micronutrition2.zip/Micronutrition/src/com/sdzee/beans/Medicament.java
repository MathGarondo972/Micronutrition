package com.sdzee.beans;

public class Medicament {
	/* Propriété du bean */
	private String libelle;
	private String posologieDefault;
	
	public void setLibelle ( String libelle) {
		this.libelle = libelle;
	}
	
	public String getLibelle() {
		return libelle;
	}
	
	public void setPosologieDefault ( String posologieDefault) {
		this.posologieDefault = posologieDefault;
	}
	
	public String getPosologieDefault() {
		return posologieDefault;
	}
}
