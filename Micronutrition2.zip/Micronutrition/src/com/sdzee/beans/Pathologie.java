package com.sdzee.beans;

public class Pathologie {
	/* Propriété du bean */
	private String libelle;
	
	public void setLibelle ( String libelle) {
		this.libelle = libelle;
	}
	
	public String getLibelle () {
		return libelle;
	}

}
