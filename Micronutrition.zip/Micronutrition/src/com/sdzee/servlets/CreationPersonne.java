package com.sdzee.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sdzee.beans.Personne;

public class CreationPersonne extends HttpServlet {
	public void doGet( HttpServletRequest request, HttpServletResponse response ) throws
ServletException, IOException{
		/* 
		 * Récupération des données saisies, envoyées en tant que paramètres de la requête
		 * GET générée à la validation du formulaire
		 */
		String nom = request.getParameter("nomPersonne");
		String prenom = request.getParameter("prenomPersonne");
		String sexe = request.getParameter("sexePersonne");
		String adresse = request.getParameter("adressePersonne");
		String codePostal = request.getParameter("codePostalPersonne");
		String ville = request.getParameter("villePersonne");
		String pays = request.getParameter("paysPersonne");
		String numeroTelephone = request.getParameter("numeroTelephonePersonne");
		String email = request.getParameter("emailPersonne");
		String motPasse = request.getParameter("motPassePersonne");
		
		String message;
		/*
		 * Initialisation du message à afficher : si un des champs obligatoires
		 * du formulaire n'est pas renseigné, alors on affiche un message
		 * d'erreur, sinon on affiche un message de succès
		 */
		
		if ( nom.trim().isEmpty() || prenom.trim().isEmpty() || sexe.trim().isEmpty() || 
				adresse.trim().isEmpty() || codePostal.trim().isEmpty() || ville.trim().isEmpty()
				|| pays.trim().isEmpty() || numeroTelephone.trim().isEmpty() || email.trim().isEmpty()
				|| motPasse.trim().isEmpty() ) {
			message = "Erreur - Vous n'avez pas rempli tous les champs obligatoires. <br> <a href=\"creerPersonne.jsp\">CLiquez ici</a> pour accéder au formulaire de création d'une personne.";
		} else {
			
			message = "Personne crée avec succès !";
		}
		/*
		 * Création du bean Personne et initialisation avec les données récupérées
		 */
		Personne personne = new Personne();
		personne.setNom(nom);
		personne.setPrenom(prenom);
		personne.setSexe(sexe);
		personne.setAdresse(adresse);
		personne.setCodePostal(codePostal);
		personne.setVille(ville);
		personne.setPays(pays);
		personne.setNumeroTelephone(numeroTelephone);
		personne.setEmail(email);
		personne.setMotPasse(motPasse);
		
		/* Ajout du bean et du message à l'objet requête */
		request.setAttribute("personne", personne);
		request.setAttribute("message", message);
		
		/* Transmission à la page JSP en charge de l'affichage des données */
		this.getServletContext().getRequestDispatcher("/afficherPersonne.jsp").
		forward(request, response);
		
	}
}
