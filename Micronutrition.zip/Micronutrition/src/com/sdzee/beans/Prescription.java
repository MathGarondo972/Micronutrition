package com.sdzee.beans;

public class Prescription {
	/* Propriété du bean 
	 * private Date date;
	 */
}
