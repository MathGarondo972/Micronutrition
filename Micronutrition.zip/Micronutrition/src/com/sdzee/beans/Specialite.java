package com.sdzee.beans;

public class Specialite {
	private String libelle;
	
	public void setLibelle ( String libelle) {
		this.libelle = libelle;
	}
	
	public String getLibelle () {
		return libelle;
	}

}
