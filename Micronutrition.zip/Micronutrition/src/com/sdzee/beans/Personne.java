package com.sdzee.beans;

public class Personne {
	/* Propriétés du bean */
	private String nom;
	private String prenom;
	private String sexe;
	private String adresse;
	private String codePostal;
	private String ville;
	private String pays;
	private String numeroTelephone;
	private String email;
	private String motPasse;
	
	public void setNom( String nom ) {
		this.nom = nom;
	}
	
	public String getNom() {
		return nom;
	}
	
	public void setPrenom( String prenom ) {
		this.prenom = prenom;
	}
	
	public String getPrenom() {
		return prenom;
	}
	
	public void setSexe( String sexe ) {
		this.sexe = sexe;
	}
	
	public String getSexe() {
		return sexe;
	}
	
	public void setAdresse( String adresse ) {
		this.adresse = adresse;
	}
	
	public String getAdresse() {
		return adresse;
	}
	
	public void setCodePostal( String codePostal ) {
		this.codePostal = codePostal;
	}
	
	public String getCodePostal() {
		return codePostal;
	}
	
	public void setVille( String ville ) {
		this.ville = ville;
	}
	
	public String getVille() {
		return ville;
	}
	
	public void setPays( String pays ) {
		this.pays = pays;
	}
	
	public String getPays() {
		return pays;
	}
	
	public void setNumeroTelephone( String numeroTelephone ) {
		this.numeroTelephone = numeroTelephone;
	}
	
	public String getNumeroTelephone() {
		return numeroTelephone;
	}
	
	public void setEmail( String email ) {
		this.email = email;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setMotPasse( String motPasse ) {
		this.motPasse = motPasse;
	}
	
	public String getMotPasse() {
		return motPasse;
	}

}
