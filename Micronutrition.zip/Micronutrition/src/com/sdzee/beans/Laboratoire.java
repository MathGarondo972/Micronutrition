package com.sdzee.beans;

public class Laboratoire {
	private String libelle;
	
	public void setLibelle ( String libelle ) {
		this.libelle = libelle;
	}
	
	public String getLibelle () {
		return libelle;
	}

}
