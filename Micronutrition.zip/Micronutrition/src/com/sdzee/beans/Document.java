package com.sdzee.beans;

public class Document {
	/* Propriété du bean */
	private String date;
	private String libelle;
	private Double taille;
	
	public void setDate (String date) {
		this.date = date;
	}
	
	public String getDate () {
		return date;
	}
	
	public void setLibelle (String libelle) {
		this.libelle = libelle;
	}
	
	public String getLibelle () {
		return libelle;
	}
	
	public void setTaille (Double taille) {
		this.taille = taille;
	}
	
	public Double getTaille () {
		return taille;
	}

}
