package com.sdzee.beans;

public class Message {
	/* Propriété du bean */
	private String date;
	private String auteur;
	private String body;
	/*private String flagLu;
	private String flagVisiblePraticien;
	private String flagVisiblePatient;*/
	
	public void setDate ( String date) {
		this.date = date;
	}
	
	public String getDate() {
		return date;
	}
	
	public void setAuteur( String auteur) {
		this.auteur = auteur;
	}
	
	public String getAuteur() {
		return auteur;
	}
	
	public void setBody (String body) {
		this.body = body;
	}
	
	public String getBody() {
		return body;
	}
}
