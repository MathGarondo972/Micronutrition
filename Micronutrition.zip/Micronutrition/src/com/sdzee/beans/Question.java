package com.sdzee.beans;

public class Question {
	/* Propriété du bean */
	/*private ordre;*/
	private String libelle;
	
	public void setLibelle (String libelle) {
		this.libelle = libelle;
	}
	
	public String getLibelle () {
		return libelle;
	}

}
