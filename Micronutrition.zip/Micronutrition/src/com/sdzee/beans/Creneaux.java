package com.sdzee.beans;

public class Creneaux {
	private String libelle;
	/* private heureDebut 
	 *private Smallint heureFin;
	 */
	
	public void setLibelle (  String libelle ) {
		this.libelle = libelle;
	}
	
	public String getLibelle () {
		return libelle;
	}
}
