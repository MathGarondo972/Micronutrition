#------------------------------------------------------------
#      Script MySQL de la Cr�ation de la Bdd 
#------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS votrerdvsante CHARACTER SET 'utf8';
USE votrerdvsante;

#------------------------------------------------------------
# Table: Personne	???
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Personne(
        idPersonne      Int  Auto_increment  NOT NULL ,
        email           Varchar (100) NOT NULL ,
        motPasse        Varchar (100) NOT NULL ,
        dateInscription Date NOT NULL ,
        nom             Varchar (100) ,
        prenom          Varchar (100) ,
        sexe            Varchar (20) ,
        adresse         Varchar (100) ,
        codePostal      Mediumint ,
        ville           Varchar (100) ,
        pays            Varchar (100) ,
        numeroTelephone Int
	,CONSTRAINT Personne_PK PRIMARY KEY (idPersonne)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Praticien
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Praticien(
        idPraticien     Int NOT NULL ,
        email           Varchar (100) NOT NULL ,
        motPasse        Varchar (100) NOT NULL ,
        dateInscription Date NOT NULL ,
        nom             Varchar (100) ,
        prenom          Varchar (100) ,
        sexe            Varchar (20) ,
        adresse         Varchar (100) ,
        codePostal      Mediumint ,
        ville           Varchar (100) ,
        pays            Varchar (100) ,
        numeroTelephone Int
	,CONSTRAINT Praticien_PK PRIMARY KEY (idPraticien)

	,CONSTRAINT Praticien_Personne_FK FOREIGN KEY (idPraticien) REFERENCES Personne(idPersonne)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Patient
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Patient(
        idPatient       Int NOT NULL ,
        email           Varchar (100) NOT NULL ,
        motPasse        Varchar (100) NOT NULL ,
        dateInscription Date NOT NULL ,
        nom             Varchar (100) ,
        prenom          Varchar (100) ,
        sexe            Varchar (20) ,
        adresse         Varchar (100) ,
        codePostal      Mediumint ,
        ville           Varchar (100) ,
        pays            Varchar (100) ,
        numeroTelephone Int
	,CONSTRAINT Patient_PK PRIMARY KEY (idPatient)

	,CONSTRAINT Patient_Personne_FK FOREIGN KEY (idPatient) REFERENCES Personne(idPersonne)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Dossier Patient
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Dossier_Patient(
        idDossierPatient     Int  Auto_increment  NOT NULL ,
        idPatient            Int NOT NULL ,
        idPraticien 		 Int NOT NULL
	,CONSTRAINT DossierPatient_PK PRIMARY KEY (idDossierPatient)

	,CONSTRAINT DossierPatient_Patient_FK FOREIGN KEY (idPatient) REFERENCES Patient(idPatient)
	,CONSTRAINT DossierPatient_Praticien0_FK FOREIGN KEY (idPraticien) REFERENCES Praticien(idPraticien)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Categorie
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Categorie(
        idCategorie Int  Auto_increment  NOT NULL ,
        libelle     Varchar (100) NOT NULL
	,CONSTRAINT Categorie_PK PRIMARY KEY (idCategorie)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Information Medicale
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Information_Medicale(
        idCategorie      Int NOT NULL ,
        idDossierPatient Int NOT NULL ,
        date             Date NOT NULL ,
        body             Varchar (100) NOT NULL
	,CONSTRAINT InformationMedicale_PK PRIMARY KEY (idCategorie,idDossierPatient)

	,CONSTRAINT InformationMedicale_Categorie_FK FOREIGN KEY (idCategorie) REFERENCES Categorie(idCategorie)
	,CONSTRAINT InformationMedicale_DossierPatient0_FK FOREIGN KEY (idDossierPatient) REFERENCES Dossier_Patient(idDossierPatient)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Message	???
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Message(
        idMessage            Int  Auto_increment  NOT NULL ,
        date                 Date NOT NULL ,
        body                 Varchar (2048) ,
        flagLu               TinyINT NOT NULL ,
        flagVisiblePraticien TinyINT NOT NULL ,
        flagVisiblePatient   TinyINT NOT NULL
	,CONSTRAINT Message_PK PRIMARY KEY (idMessage)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Message Praticien
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Message_Praticien(
        idMessagePraticien   Int NOT NULL ,
        date                 Date NOT NULL ,
        body                 Varchar (2048) ,
        flagLu               TinyINT NOT NULL ,
        flagVisiblePraticien TinyINT NOT NULL ,
        flagVisiblePatient   TinyINT NOT NULL ,
        idPraticien          Int NOT NULL ,
        idDossierPatient     Int NOT NULL
	,CONSTRAINT MessagePraticien_PK PRIMARY KEY (idMessagePraticien)

	,CONSTRAINT MessagePraticien_Message_FK FOREIGN KEY (idMessagePraticien) REFERENCES Message(idMessage)
	,CONSTRAINT MessagePraticien_Praticien0_FK FOREIGN KEY (idPraticien) REFERENCES Praticien(idPraticien)
	,CONSTRAINT MessagePraticien_DossierPatient1_FK FOREIGN KEY (idDossierPatient) REFERENCES Dossier_Patient(idDossierPatient)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Message Patient
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Message_Patient(
        idMessagePatient     Int NOT NULL ,
        date                 Date NOT NULL ,
        body                 Varchar (2048) ,
        flagLu               TinyINT NOT NULL ,
        flagVisiblePraticien TinyINT NOT NULL ,
        flagVisiblePatient   TinyINT NOT NULL ,
        idPatient            Int NOT NULL ,
        idDossierPatient     Int NOT NULL
	,CONSTRAINT MessagePatient_PK PRIMARY KEY (idMessagePatient)

	,CONSTRAINT MessagePatient_Message_FK FOREIGN KEY (idMessagePatient) REFERENCES Message(idMessage)
	,CONSTRAINT MessagePatient_Patient0_FK FOREIGN KEY (idPatient) REFERENCES Patient(idPatient)
	,CONSTRAINT MessagePatient_DossierPatient1_FK FOREIGN KEY (idDossierPatient) REFERENCES Dossier_Patient(idDossierPatient)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Document	???
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Document(
        idDocument  Int  Auto_increment  NOT NULL ,
        date        Date NOT NULL ,
        libelle     Varchar (100) ,
        taille_     Double ,
        flagVisible TinyINT NOT NULL
	,CONSTRAINT Document_PK PRIMARY KEY (idDocument)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Document Praticien
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Document_Praticien(
        idDocumentPraticien  Int NOT NULL ,
        date        		 Date NOT NULL ,
        libelle     		 Varchar (100) ,
        taille_     		 Double ,
        flagVisible 		 TinyINT NOT NULL ,
        idPraticien  		 Int NOT NULL
	,CONSTRAINT DocumentPraticien_PK PRIMARY KEY (idDocumentPraticien)

	,CONSTRAINT DocumentPraticien_Document_FK FOREIGN KEY (idDocumentPraticien) REFERENCES Document(idDocument)
	,CONSTRAINT DocumentPraticien_Praticien0_FK FOREIGN KEY (idPraticien) REFERENCES Praticien(idPraticien)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Document Praticien Partager
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Document_Praticien_Partager(
        idDossierPatient 	 Int NOT NULL ,
        idDocumentPraticien  Int NOT NULL ,
        flagVisible      	 TinyINT NOT NULL
	,CONSTRAINT DocumentPraticienPartager_PK PRIMARY KEY (idDossierPatient,idDocumentPraticien)

	,CONSTRAINT DocumentPraticienPartager_DossierPatient_FK FOREIGN KEY (idDossierPatient) REFERENCES Dossier_Patient(idDossierPatient)
	,CONSTRAINT DocumentPraticienPartager_DocumentPraticien0_FK FOREIGN KEY (idDocumentPraticien) REFERENCES Document_Praticien(idDocumentPraticien)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Document Patient
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Document_Patient(
        idDocumentPatient Int NOT NULL ,
        date              Date NOT NULL ,
        libelle           Varchar (100) ,
        taille_           Double ,
        flagVisible       TinyINT NOT NULL ,
        idPatient         Int NOT NULL ,
        idDossierPatient  Int NOT NULL
	,CONSTRAINT DocumentPatient_PK PRIMARY KEY (idDocumentPatient)

	,CONSTRAINT DocumentPatient_Document_FK FOREIGN KEY (idDocumentPatient) REFERENCES Document(idDocument)
	,CONSTRAINT DocumentPatient_Patient0_FK FOREIGN KEY (idPatient) REFERENCES Patient(idPatient)
	,CONSTRAINT DocumentPatient_DossierPatient1_FK FOREIGN KEY (idDossierPatient) REFERENCES Dossier_Patient(idDossierPatient)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Specialite
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Specialite(
        idSpecialite Int  Auto_increment  NOT NULL ,
        libelle      Varchar (100) NOT NULL
	,CONSTRAINT Specialite_PK PRIMARY KEY (idSpecialite)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Specialite Praticien
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Specialite_Praticien(
        idSpecialite Int  NOT NULL ,
		idPraticien  Int  NOT NULL ,
        libelle      Varchar (100) NOT NULL
	,CONSTRAINT SpecialitePraticien_PK PRIMARY KEY (idSpecialite,idPraticien)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Motif
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Motif(
        idMotif Int   Auto_increment  NOT NULL ,
        libelle       Varchar (100) NOT NULL ,
        idSpecialite  Int NOT NULL 
	,CONSTRAINT Motif_PK PRIMARY KEY (idMotif)
	
	,CONSTRAINT Motif_Specialite_FK FOREIGN KEY (idSpecialite) REFERENCES Specialite(idSpecialite)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Duree
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Duree(
        idDuree      Int  Auto_increment  NOT NULL ,
        nbrMinutes   Smallint NOT NULL
	,CONSTRAINT Duree_PK PRIMARY KEY (idDuree)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Consultation
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Consultation(
        idConsultation       	Int  Auto_increment  NOT NULL ,
        libelle            		Varchar (100) ,
        tarif               	Double ,
        idPraticien          	Int NOT NULL ,
        idMotif        			Int NOT NULL ,
        idDureeConsultation     Int NOT NULL ,
        idDureeTampon 			Int NOT NULL
	,CONSTRAINT Consultation_PK PRIMARY KEY (idConsultation)

	,CONSTRAINT Consultation_Praticien_FK FOREIGN KEY (idPraticien) REFERENCES Praticien(idPraticien)
	,CONSTRAINT Consultation_Motif0_FK FOREIGN KEY (idMotif) REFERENCES Motif(idMotif)
	,CONSTRAINT Consultation_DureeConsultation1_FK FOREIGN KEY (idDureeConsultation) REFERENCES Duree(idDuree)
	,CONSTRAINT Consultation_DureeTampon2_FK FOREIGN KEY (idDureeTampon) REFERENCES Duree(idDuree)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Type Paiement
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Type_Paiement(
        idTypePaiement Int  Auto_increment  NOT NULL ,
        libelle        Varchar (100) NOT NULL
	,CONSTRAINT TypePaiement_PK PRIMARY KEY (idTypePaiement)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Type Paiement Practicien
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Type_Paiement_Practicien(
        idTypePaiement Int NOT NULL ,
        idPraticien    Int NOT NULL
	,CONSTRAINT TypePaiementPracticien_PK PRIMARY KEY (idTypePaiement,idPraticien)

	,CONSTRAINT TypePaiementPracticien_TypePaiement_FK FOREIGN KEY (idTypePaiement) REFERENCES Type_Paiement(idTypePaiement)
	,CONSTRAINT TypePaiementPracticien_Praticien0_FK FOREIGN KEY (idPraticien) REFERENCES Praticien(idPraticien)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Laboratoire
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Laboratoire(
        idLaboratoire Int  Auto_increment  NOT NULL ,
        libelle       Varchar (100) ,
        idPraticien   Int
	,CONSTRAINT Laboratoire_PK PRIMARY KEY (idLaboratoire)

	,CONSTRAINT Laboratoire_Praticien_FK FOREIGN KEY (idPraticien) REFERENCES Praticien(idPraticien)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Medicament
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Medicament(
        idMedicament     Int  Auto_increment  NOT NULL ,
        libelle          Varchar (100) ,
        posologieDefault Varchar (100) ,
        idLaboratoire    Int NOT NULL
	,CONSTRAINT Medicament_PK PRIMARY KEY (idMedicament)

	,CONSTRAINT Medicament_Laboratoire_FK FOREIGN KEY (idLaboratoire) REFERENCES Laboratoire(idLaboratoire)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Prescription
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Prescription(
        idPrescription   Int  Auto_increment  NOT NULL ,
        date             Date NOT NULL ,
        idDossierPatient Int NOT NULL
	,CONSTRAINT Prescription_PK PRIMARY KEY (idPrescription)

	,CONSTRAINT Prescription_DossierPatient_FK FOREIGN KEY (idDossierPatient) REFERENCES Dossier_Patient(idDossierPatient)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Ligne Prescription
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Ligne_Prescription(
        idPrescription Int NOT NULL ,
        idMedicament   Int NOT NULL ,
        libelle        Varchar (50) NOT NULL ,
        posologie      Varchar (100) NOT NULL
	,CONSTRAINT LignePrescription_PK PRIMARY KEY (idPrescription,idMedicament)

	,CONSTRAINT LignePrescription_Prescription_FK FOREIGN KEY (idPrescription) REFERENCES Prescription(idPrescription)
	,CONSTRAINT LignePrescription_Medicament0_FK FOREIGN KEY (idMedicament) REFERENCES Medicament(idMedicament)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Heure
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Heure(
        idHeure  Int  Auto_increment  NOT NULL ,
        ordre_   Smallint NOT NULL ,
        libelle_ Varchar (50)
	,CONSTRAINT Heure_PK PRIMARY KEY (idHeure)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Creneau	???
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Creneau(
        idCreneau          Int  Auto_increment  NOT NULL ,
        libelle            Varchar (100) ,
        idHeureDebut       Int NOT NULL ,
        idHeureFin 	   	   Int NOT NULL
	,CONSTRAINT Creneau_PK PRIMARY KEY (idCreneau)

	,CONSTRAINT Creneau_HeureDebut_FK FOREIGN KEY (idHeureDebut) REFERENCES Heure(idHeure)
	,CONSTRAINT Creneau_HeureFin0_FK FOREIGN KEY (idHeureFin) REFERENCES Heure(idHeure)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Jour
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Jour(
        idJour  Int  Auto_increment  NOT NULL ,
        libelle Varchar (50) NOT NULL
	,CONSTRAINT Jour_PK PRIMARY KEY (idJour)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Creneau Semaine Type
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Creneau_Semaine_Type(
        idCreneauSemaineType  Int NOT NULL ,
        libelle_              Varchar (100) ,
        idPraticien           Int NOT NULL ,
        idJour                Int NOT NULL ,
        idHeureDebut          Int NOT NULL ,
        idHeureFin            Int NOT NULL
	,CONSTRAINT CreneauSemaineType_PK PRIMARY KEY (idCreneauSemaineType)

	,CONSTRAINT CreneauSemaineType_Creneau_FK FOREIGN KEY (idCreneauSemaineType) REFERENCES Creneau(idCreneau)
	,CONSTRAINT CreneauSemaineType_Praticien0_FK FOREIGN KEY (idPraticien) REFERENCES Praticien(idPraticien)
	,CONSTRAINT CreneauSemaineType_Jour1_FK FOREIGN KEY (idJour) REFERENCES Jour(idJour)
	,CONSTRAINT CreneauSemaineType_HeureDebut2_FK FOREIGN KEY (idHeureDebut) REFERENCES Heure(idHeure)
	,CONSTRAINT CreneauSemaineType_HeureFin3_FK FOREIGN KEY (idHeureFin) REFERENCES Heure(idHeure)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Type Creneau
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Type_Creneau(
        idTypeCreneau Int  Auto_increment  NOT NULL ,
        libelle       Varchar (100)
	,CONSTRAINT TypeCreneau_PK PRIMARY KEY (idTypeCreneau)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Creneau Supplementaire
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Creneau_Supplementaire(
        idCreneauSupplementaire  Int NOT NULL ,
        dateDebut          		 Date NOT NULL ,
        dateFin            		 Date ,
        libelle_           		 Varchar (100) ,
        idPraticien         	 Int NOT NULL ,
        idTypeCreneau      		 Int NOT NULL ,
        idHeureDebut       		 Int NOT NULL ,
        idHeureFin         		 Int NOT NULL
	,CONSTRAINT CreneauSupplementaire_PK PRIMARY KEY (idCreneauSupplementaire)

	,CONSTRAINT CreneauSuppementaire_Creneau_FK FOREIGN KEY (idCreneauSupplementaire) REFERENCES Creneau(idCreneau)
	,CONSTRAINT CreneauSuppementaire_Praticien0_FK FOREIGN KEY (idPraticien) REFERENCES Praticien(idPraticien)
	,CONSTRAINT CreneauSuppementaire_TypeCreneau1_FK FOREIGN KEY (idTypeCreneau) REFERENCES Type_Creneau(idTypeCreneau)
	,CONSTRAINT CreneauSuppementaire_HeureDebut2_FK FOREIGN KEY (idHeureDebut) REFERENCES Heure(idHeure)
	,CONSTRAINT CreneauSuppementaire_HeureFin3_FK FOREIGN KEY (idHeureFin) REFERENCES Heure(idHeure)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Status
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Status(
        idStatut Int  Auto_increment  NOT NULL ,
        libelle  Varchar (100) NOT NULL
	,CONSTRAINT Status_PK PRIMARY KEY (idStatut)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Creneau Rdv
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Creneau_Rdv(
        idCreneauRdv           Int NOT NULL ,
        dateRdv             Date NOT NULL ,
        hashcode            Varchar (100) ,
        Montant             Double ,
        dateQuestionnaire   Date NOT NULL ,
        libelle_            Varchar (100) ,
        idDossierPatient    Int NOT NULL ,
        idTypePaiement      Int ,
        idStatut            Int NOT NULL ,
        idConsultation		Int NOT NULL ,
        idHeureDebut        Int NOT NULL ,
        idHeureFin          Int NOT NULL
	,CONSTRAINT CreneauRdv_PK PRIMARY KEY (idCreneauRdv)

	,CONSTRAINT CreneauRdv_Creneau_FK FOREIGN KEY (idCreneauRdv) REFERENCES Creneau(idCreneau)
	,CONSTRAINT CreneauRdv_DossierPatient0_FK FOREIGN KEY (idDossierPatient) REFERENCES Dossier_Patient(idDossierPatient)
	,CONSTRAINT CreneauRdv_TypePaiement1_FK FOREIGN KEY (idTypePaiement) REFERENCES Type_Paiement(idTypePaiement)
	,CONSTRAINT CreneauRdv_Status2_FK FOREIGN KEY (idStatut) REFERENCES Status(idStatut)
	,CONSTRAINT CreneauRdv_Consultation3_FK FOREIGN KEY (idConsultation) REFERENCES Consultation(idConsultation)
	,CONSTRAINT CreneauRdv_HeureDebut4_FK FOREIGN KEY (idHeureDebut) REFERENCES Heure(idHeure)
	,CONSTRAINT CreneauRdv_HeureFin5_FK FOREIGN KEY (idHeureFin) REFERENCES Heure(idHeure)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Item
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Item(
        idItem  Int  Auto_increment  NOT NULL ,
        libelle Varchar (100) NOT NULL
	,CONSTRAINT Item_PK PRIMARY KEY (idItem)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Message Item
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Message_Item(
        idMessageItem Int  Auto_increment  NOT NULL ,
        scoreMin      TinyINT ,
        scoreMax      TinyINT ,
        idItem        Int NOT NULL
	,CONSTRAINT MessageItem_PK PRIMARY KEY (idMessageItem)

	,CONSTRAINT MessageItem_Item_FK FOREIGN KEY (idItem) REFERENCES Item(idItem)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Question
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Question(
        idQuestion Int  Auto_increment  NOT NULL ,
        ordre      Smallint NOT NULL ,
        libelle    Varchar (100) NOT NULL
	,CONSTRAINT Question_PK PRIMARY KEY (idQuestion)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Reponse
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Reponse(
        idReponse     Int  Auto_increment  NOT NULL ,
        ordre         Smallint NOT NULL ,
        libelle       Varchar (100) ,
        idQuestion    Int NOT NULL ,
        idCreneauRdv  Int NOT NULL
	,CONSTRAINT Reponse_PK PRIMARY KEY (idReponse)

	,CONSTRAINT Reponse_Question_FK FOREIGN KEY (idQuestion) REFERENCES Question(idQuestion)
	,CONSTRAINT Reponse_CreneauRdv0_FK FOREIGN KEY (idCreneauRdv) REFERENCES Creneau_Rdv(idCreneauRdv)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Score Reponse Item
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Score_Reponse_Item(
        idItem    Int NOT NULL ,
        idReponse Int NOT NULL ,
        score     DOUBLE NOT NULL
	,CONSTRAINT ScoreReponseItem_PK PRIMARY KEY (idItem,idReponse)

	,CONSTRAINT ScoreReponseItem_Item_FK FOREIGN KEY (idItem) REFERENCES Item(idItem)
	,CONSTRAINT ScoreReponseItem_Reponse0_FK FOREIGN KEY (idReponse) REFERENCES Reponse(idReponse)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Score Item
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Score_Item(
        idItem       Int NOT NULL ,
        idCreneauRdv Int NOT NULL ,
        score        DOUBLE NOT NULL
	,CONSTRAINT ScoreItem_PK PRIMARY KEY (idItem,idCreneauRdv)

	,CONSTRAINT ScoreItem_Item_FK FOREIGN KEY (idItem) REFERENCES Item(idItem)
	,CONSTRAINT ScoreItem_CreneauRdv0_FK FOREIGN KEY (idCreneauRdv) REFERENCES Creneau_Rdv(idCreneauRdv)
)ENGINE=InnoDB;

