﻿#------------------------------------------------------------
#      Script MySQL de la MàJ du Questionnaire de la Bdd 
#------------------------------------------------------------

USE votrerdvsante;


#------------------------------------------------------------
# Table: Item
#------------------------------------------------------------

INSERT INTO Item (libelle) 
VALUES ("activité"),("acidité"),("proetc. cellulaire"),("commu. cellulaire"),("cerveau"),("cardio"),("digestion"),
("scoreA"),("scoreB"),("scoreC"),("scoreD"),("scoreE"),("scoreF"),("scoreG"),("dopamine"),
("noradrénaline"),("sérotonine"),("Carence en fer");


#------------------------------------------------------------
# Table: Message Item
#------------------------------------------------------------


#------------------------------------------------------------
# Table: Question
#------------------------------------------------------------


#------------------------------------------------------------
# Table: Score Reponse Item
#------------------------------------------------------------

INSERT INTO Score_Reponse_Item (score) 
VALUES (0.5),(1.0),(2.0),(3.0),(4.0);